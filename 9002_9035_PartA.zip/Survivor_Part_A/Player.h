//Γεωργόπουλος Αναστάσιος       9002        6980810910      gganasta@ece.auth.gr
//Ρακοβαλής Παντελεήμων         9035        6983397992      pantrako@ece.auth.gr

#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED
#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;
//δημιουργία κλάσης Player
class Player{
//δήλωση μεταβλητών
    string onoma;
    string fylo;
    string epaggelma;
    string fagito;
    string antikeimeno;
    string omada;
    int ilikia;
    int peina;
    int dynami;

public:
//δήλωση συναρτήσεων αρχικών και τελικών συνθηκών
    Player();
    Player(string on, string fyl, string epag, string fag, string ant, string oma, int ilik);
    ~Player();
//δήλωση setter και getter με εμβόλιμη υλοποίηση της συνάρτησης
    void setOnoma (string value)        {onoma=value;}
    void setFylo (string value)         {fylo=value;}
    void setEpaggelma (string value)    {epaggelma=value;}
    void setFagito (string value)       {fagito=value;}
    void setAntikeimeno (string value)  {antikeimeno=value;}
    void setOmada (string value)        {omada=value;}
    void setIlikia (int value)          {ilikia=value;}
    void setPeina (int value)           {peina=value;}
    void setDynami (int value)          {dynami=value;}

    string getOnoma()                   {return onoma;}
    string getFylo()                    {return fylo;}
    string getEpaggelma()               {return epaggelma;}
    string getFagito()                  {return fagito;}
    string getAntikeimeno()             {return antikeimeno;}
    string getOmada()                   {return omada;}
    int getIlikia()                     {return ilikia;}
    int getPeina()                      {return peina;}
    int getDynami()                     {return dynami;}

//δήλωση συναρτήσεων δράσης του παίκτη
    void douleuei();
    void troei();
    void koimatai();
    void agonizetai();
};


#endif // PLAYER_H_INCLUDED
