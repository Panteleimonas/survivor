//Γεωργόπουλος Αναστάσιος       9002        6980810910      gganasta@ece.auth.gr
//Ρακοβαλής Παντελεήμων         9035        6983397992      pantrako@ece.auth.gr

#ifndef TEAM_H_INCLUDED
#define TEAM_H_INCLUDED
#include "Player.h"     //χρειάστηκε για να ορίσουμε τα αντικείμενα στον πίνακα της ομάδας
#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;
//δήλωση κλάσης Team
class Team{
//δήλωση μεταβλητών
    string onoma;
    int players;
    int nikesDiadromon;
    int nikesAgonismaton;
    Player matrix[10];      //πίνακας αντικειμένων τύπου Player

public:
//δήλωση συναρτήσεων αρχικών και τελικών συνθηκών
    Team();
    Team(string on, int pla, int nD, int nA);
    ~Team();
//δήλωση setter και getter με εμβόλιμες υλοποιήσεις συναρτήσεων
    void setOnoma (string value)            {onoma=value;}
    void setPlayers (int value)             {players=value;}
    void setNikesDiadromon (int value)      {nikesDiadromon=value;}
    void setNikesAgonismaton (int value)    {nikesAgonismaton=value;}
    void setMatrix(Player value, int i)     {matrix[i]=value;}

    string getOnoma()                       {return onoma;}
    int getPlayers()                        {return players;}
    int getNikesDiadromon()                 {return nikesDiadromon;}
    int getNikesAgonismaton()               {return nikesAgonismaton;}
    Player getMatrix(int i)                 {return matrix[i];}

//δήλωση συνάρτησης μετρησης των παικτων της ομάδας
    void counterPlayer();
};


#endif // TEAM_H_INCLUDED
