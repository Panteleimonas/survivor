//Γεωργόπουλος Αναστάσιος       9002        6980810910      gganasta@ece.auth.gr
//Ρακοβαλής Παντελεήμων         9035        6983397992      pantrako@ece.auth.gr

#include "Player.h"

using namespace std;
//υλοποίηση των συναρτήσεων δράσης του παίκτη
void Player::douleuei(){
    int x;
//επιλογή τυχαίου αριθμού μεταξύ 0,3 και 0,6 για το x
    do{
        x=rand();
    }while(x<=0.3 && x>=0.6);
    dynami = dynami - dynami*x;
    peina = peina + peina*0.2;
}

void Player::troei(){
    int x;
    do{
        x=rand();
    }while(x<=0.1 && x>=0.4);
    dynami = dynami + x;
    peina = peina - 80;
}

void Player::koimatai(){
    dynami=100;
}

void Player::agonizetai(){
    int x;
    do{
        x=rand();
    }while(x<=0.2 && x>=0.5);
    dynami = dynami - dynami*x;
    peina = peina + 25;
}

//υλοποίηση των συναρτήσεων αρχικών συνθηκών
Player::Player(){
    onoma="";
    fylo="";
    epaggelma="";
    fagito="";
    antikeimeno="";
    omada="";
    ilikia=0;
    peina=0;
    dynami=100;
}

Player::Player(string on, string fyl, string epag, string fag, string ant, string oma, int ilik){
    onoma=on;
    fylo=fyl;
    epaggelma=epag;
    fagito=fag;
    antikeimeno=ant;
    omada=oma;
    ilikia=ilik;
    peina=0;
    dynami=100;
}
//υλοποίηση συνάρτησης τελικών συνθηκών
Player::~Player(){
   // cout << "o paiktis " << onoma << " apoxorise" << endl;
}

