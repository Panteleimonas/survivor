//Γεωργόπουλος Αναστάσιος       9002        6980810910      gganasta@ece.auth.gr
//Ρακοβαλής Παντελεήμων         9035        6983397992      pantrako@ece.auth.gr

#include "Team.h"

using namespace std;
//υλοποίηση συναρτήσεων αρχικών συνθηκών
Team::Team(){
    onoma="";
    players=0;
    nikesDiadromon=0;
    nikesAgonismaton=0;
}

Team::Team(string on, int pla, int nD, int nA){
    onoma=on;
    players=pla;
    nikesDiadromon=nD;
    nikesAgonismaton=nA;
}
//υλοποίηση συνάρτησης τελικών συνθηκών
Team::~Team(){
    cout << "i omada "<< onoma << " dialithike" << endl;
}

//υλοποίηση μετρητή Παικτών Ομάδας
void Team::counterPlayer(){
//έλεγχος πληρώτητας ομάδας
    if(players<10){
        players++;
    }
    else{
        cout << "I omada einai pliris.\n " << endl;
    }
}


