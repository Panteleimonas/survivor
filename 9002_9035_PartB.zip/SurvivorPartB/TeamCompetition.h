#ifndef TEAMCOMPETITION_H_INCLUDED
#define TEAMCOMPETITION_H_INCLUDED

#include "Competition.h"
#include "FoodAward.h"
#include "Round.h"
#include "Team.h"
#include "Player.h"

using namespace std;

class TeamCompetition: public Competition
{
    FoodAward foodAward;
    Round rounds[19];

public:
    TeamCompetition();
    TeamCompetition(int id, string name, string winner, string v1, bool v2);
    ~TeamCompetition();

    Round* getRounds()          {return rounds;} //epistrefei tin proti thesi tou pinaka antikeimenwn rounds[] gi auto xrisimopoiisame to *
    FoodAward getfoodAward()    {return foodAward;} //epistrefei tin proti thesi tou antikeimenou

    void setRound(int v1, int v2, string v3);
    void setFoodAward(string v1, bool v2, int v3);

    void status();
    int compete(Team &team1,Team &team2);

};

#endif // TEAMCOMPETITION_H_INCLUDED
