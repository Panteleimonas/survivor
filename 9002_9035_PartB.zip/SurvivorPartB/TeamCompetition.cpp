#include "TeamCompetition.h"

TeamCompetition::TeamCompetition()
{
    FoodAward(); //klisi tou constructor ths class FoodAward
}

TeamCompetition::TeamCompetition(int id, string name, string winner, string v1, bool v2) : Competition(id, name, winner)
{
    FoodAward(v1, v2); //klisi tou constructor ths class FoodAward me orismata
}

TeamCompetition::~TeamCompetition(){}

void TeamCompetition::status()
{
    int i=0;
    Competition::status(); //klhsh ths status apo tin competition
    foodAward.status();    //klhsh ths status apo to antikeimeno foodAward
    for(i=0;i<19;i++)
    {
        rounds[i].status(); //klhsh ths status gia kathe antikeimeno tou pinaka
    }

}

void TeamCompetition::setFoodAward(string v1, bool v2, int v3)
{
    foodAward.setName(v1);
    foodAward.setSolo(v2);
    foodAward.setBonusSupplies(v3);
}

void TeamCompetition::setRound(int v1, int v2, string v3)
{
    int i=v1;
    if(i<19)
    {
        rounds[i].setId(v1);
        rounds[i].setDuration(v2);
        rounds[i].setWinner(v3);
    }
    else
    {
        cout << "the game should have ended already" << endl; //asfalistiki diklida gia pithano sfalma tou kodika
    }
}

int TeamCompetition::compete(Team &team1,Team &team2)
{
    int wins1=0,wins2=0;
    int x=0,i=0;

//competition
    while(wins1<10 && wins2<10)
    {
        Player *t1,*t2;

        t1=team1.getPlayers();
        t2=team2.getPlayers();
//select random player
        x=rand()%10;
        t1 += x;
        x=rand()%10;
        t2 += x;

//contestants status
//        cout << "Player from " << team1.getName() << " is:";
//        t1->status();
//        cout << "Player from " << team2.getName() << " is:";
//        t2->status();
//        cout << endl;

        t1->compete();
        t2->compete();

        if (t1->getPower() > t2->getPower())
        {
            setRound(i,500,t1->getName());
            wins1++;
        }
        else if(t1->getPower() < t2->getPower())
        {
            setRound(i,500,t2->getName());
            wins2++;
        }
        else if(t1->getPower() == t2->getPower())
        {
            if(t1->getHunger() < t2->getHunger())
            {
                setRound(i,500,t1->getName());
                wins1++;
            }
            else if(t1->getHunger() > t2->getHunger())
            {
                setRound(i,500,t2->getName());
                wins2++;
            }
        }
//select a random winner
        else
        {
            x=rand()%2;     //coin flipping
            if(x==0)
            {
                setRound(i,500,t1->getName());
                wins1++;
            }
            else
            {
                setRound(i,500,t2->getName());
                wins2++;
            }
        }
        //print results from each round
        rounds[i].status();
        i++;    //go to next round
    }
////print results from all rounds
//    for(i=0;i<19;i++)
//    {
//        rounds[i].status();
//    }
//set Awards
    if(wins1==10)
    {
        //set win
        int k;
        k=team1.getWins() + 1;
        team1.setWins(k);
        //set supply
        k=foodAward.getBonusSupplies();
        team1.setSupplies(k);
        return 1;
    }
    else
    {
        int k;
        k=team2.getWins() + 1;
        team2.setWins(k);

        k=foodAward.getBonusSupplies();
        team2.setSupplies(k);
        return 0;
    }

}
