//  DIKO MAS
#include "Competition.h"

Competition::Competition()
{
    id=0;
    name="";
    winner="";
};

Competition::Competition(int id, string name, string winner)
{
    id=id;
    name=name;
    winner=winner;
}

void Competition::status()
{
    cout << getId() << endl;
    cout << getName() << endl;
    cout << getWinner() << endl;
}

Competition::~Competition(){}
