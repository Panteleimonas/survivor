#ifndef QUIZCOMPETITION_H_INCLUDED
#define QUIZCOMPETITION_H_INCLUDED

#include "Competition.h"
#include "CommunicationAward.h"
#include "Round.h"
#include "Team.h"
#include "Player.h"

using namespace std;

class QuizCompetition : public Competition
{
    CommunicationAward communicationAward;

    Round rounds[19];
    static string questions[10];
    static int answers[10];

public:
    QuizCompetition();
    QuizCompetition(int id, string name, string winner, string v1, bool v2);
    ~QuizCompetition();


    void setCommunicationAward(CommunicationAward val)  {communicationAward = val;}
    void setRound(int v1, int v2, string v3);


    CommunicationAward getCommunicationAward()  {return communicationAward;}
    Round *getRounds()                          {return rounds;}
    string getQuestions(int i)                  {return questions[i];}
    int getAnswers(int i)                       {return answers[i];}

    void status();
    void compete(Team &team1,Team &team2);
};

#endif // QUIZCOMPETITION_H_INCLUDED
