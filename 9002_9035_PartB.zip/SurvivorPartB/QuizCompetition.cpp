#include "QuizCompetition.h"

using namespace std;

string QuizCompetition::questions[10]={"How many women has Spaliaras slept with?","How many Nobel prizes have been won by Greeks?","How many Tsangks are there in China?","Which is the number in the jersey of LeBron James?","How many stars are in Panos jersey?","How many books are in Choutos' Library?","How many fans are out there loving Danos?","How many pounds are in one kilogram?","How much is the fish?","How many characters in the mandarene alphabet?"};
int QuizCompetition::answers[10]={4000,2,100000,23,12,1,200000,2,10,6500};

QuizCompetition::QuizCompetition()
{
    CommunicationAward();
}

QuizCompetition::QuizCompetition(int id, string name, string winner, string v1, bool v2) : Competition(id, name, winner)
{
    CommunicationAward(v1,v2);
}

QuizCompetition::~QuizCompetition(){}

void QuizCompetition::setRound(int v1, int v2, string v3)
{
    int i=v1;
    if(i<19)
    {
        rounds[i].setId(v1);
        rounds[i].setDuration(v2);
        rounds[i].setWinner(v3);
    }
    else
    {
        cout << "the game should have ended already" << endl;
    }
}

void QuizCompetition::status()
{
    Competition::status();
    communicationAward.status();
    cout << "Round status:" << getRounds() << endl;
}

void QuizCompetition::compete(Team &team1,Team &team2)
{
    int wins1=0,wins2=0;
    int x=0,i=0,q,a1,a2,b1,b2;

//competition
    while(wins1<10 && wins2<10)
    {
        Player *t1,*t2;

        t1=team1.getPlayers();
        t2=team2.getPlayers();
//select random player
        x=rand()%10;
        t1 += x;
        x=rand()%10;
        t2 += x;

//contestants status
//        cout << "Player from " << team1.getName() << " is:";
//        t1->status();
//        cout << "Player from " << team2.getName() << " is:";
//        t2->status();
//        cout << endl;

        q=rand()%10;

        a1=rand()%10;
        a2=rand()%10;

        b1=abs(q-a1);
        b2=abs(q-a2);
        if(b1 < b2)
        {
            setRound(i,20,t1->getName());
            wins1++;
        }
        else if(b1 > b2)
        {
            setRound(i,20,t2->getName());
            wins2++;
        }
        else
        {
            x=rand()%2;     //coin flipping
            if(x==0)
            {
                setRound(i,20,t1->getName());
                wins1++;
            }
            else
            {
                setRound(i,20,t2->getName());
                wins2++;
            }
        }

        //print each question and answer
        cout << "\tQ:  " << questions[q] << endl;
        cout << "\tA:  " << team1.getName() << " answer: " << answers[a1] << "\n\t    " << team2.getName() << " answer: " << answers[a2] << endl;
        //go to next round
        i++;
    }

    //print results from all rounds
    for(i=0; i<19; i++)
    {
        rounds[i].status();
    }

    //set Awards
    if(wins1==10)
    {
        //set win
        int k;
        k=team1.getWins() + 1;
        team1.setWins(k);
        return;
    }
    else
    {
        int k;
        k=team2.getWins() + 1;
        team2.setWins(k);
        return;
    }

}

