#include "ImmunityCompetition.h"

ImmunityCompetition::ImmunityCompetition()
{
    ImmunityAward();
}

ImmunityCompetition::ImmunityCompetition(int id, string name, string winner, string v1, bool v2) : Competition(id, name, winner)
{
    ImmunityAward(v1, v2);
}

ImmunityCompetition::~ImmunityCompetition(){}


void ImmunityCompetition::status()
{
    Competition::status();
    immunityAward.status();
}

void ImmunityCompetition::setImmunityAward(string v1, bool v2, int v3)
{
    immunityAward.setName(v1);
    immunityAward.setSolo(v2);
    immunityAward.setVotes(v3);
}

void ImmunityCompetition::compete(Team &value)
{
    Player *p,*p1;
    float x, playerPowers[10][2];
    int i=0, j=0, k=0;
    p=value.getPlayers();
    p1=value.getPlayers();

    for(i=0; i<10; i++)
    {
        playerPowers[i][1]=p->getPower();
        playerPowers[i][2]=i;
        p++;
    }

    for(i=0; i<10; i++)
    {
        for(j=9; j>=i; j--)
        {
            if(playerPowers[j-1][1]>playerPowers[j][1])
            {
                x=playerPowers[j-1][1];
                playerPowers[j-1][1]=playerPowers[j][1];
                playerPowers[j][1]=x;
            }
        }
    }
    k=(int)playerPowers[1][2];
    p1 += k; //winner's position
    cout << "and the winner is..." << endl;
    p1->status();


}

