//������������ ����������       9002        6980810910      gganasta@ece.auth.gr
//��������� �����������         9035        6983397992      pantrako@ece.auth.gr

#include <iostream>

#include <windows.h>        //aparaitites gia tin
#include <mmsystem.h>       //anaparagogi hxou

#include "Team.h"
#include "QuizCompetition.h"
#include "TeamCompetition.h"
#include "ImmunityCompetition.h"

using namespace std;

Team teams[2] = { Team("Diasimoi"), Team("Maxites")};
int competitionId = 0;
void menu();
void normalDay();
void teamCompetitionDay();
void quizDay();

int main()
{
    menu();

    return 0;
}

void menu()
{
    int choice = -1;

    while(choice != 0)
    {
        cout << "1.Normal Day." << endl;
        cout << "2.Team Competition Day." << endl;
        cout << "3.Quiz Day." << endl;
        cout << "0.Quit" << endl;

        cin >> choice;

        switch(choice)
        {

        case 1:
            normalDay();
            break;
        case 2:
            teamCompetitionDay();
            break;
        case 3:
            quizDay();
            break;
        case 0:
            break;
        default:
            cout << "Incorrect Input. Choose between 1 and 3. Press 0 to quit." << endl;

        }
    }

    cout << endl << endl;
    cout << "Thank you for Playing" << endl << endl
         << "Now you are listening \"Starvation\" By Thomas Bergersen" << endl << endl
         << "Programmers: \n\tGeorgopoulos Anastasis\n\tRakovalis Pantelis" << endl;

    PlaySound("Thomas Bergersen - Starvation.wav",NULL,SND_SYNC);


    cout << "wish we see you again" << endl;

}

void normalDay()
{
    cout << endl;
    cout << "This is a normal day in the Survivor Game." << endl << endl;

    cout << "Everybody is happy now... \nThere is no competition for our lovely players, \nbut they have so many to do about themselves! \nFirst of all they work as a team (like cleaning, fishing, cooking)" << endl;

    cout << "." << endl;
    teams[0].teamWorks();
    teams[1].teamWorks();
    teams[0].teamEats();
    teams[1].teamEats();
    cout << "." << endl;

    teams[0].teamSleeps();
    teams[1].teamSleeps();

    cout << "While you are reading this, they are sleeping to rest for tomorrow's day" << endl << endl;

}

void teamCompetitionDay()
{
    cout << "This is a team competition day in the Survivor Game." << endl << endl;

    teams[0].teamWorks();
    teams[1].teamWorks();


    cout << "Today our thinking players are preparing for the Competition. \nNo one speaks. \nLet's watch them playing while Laoura is coming form the beach." << endl << endl;
    cout << "Let us know which is going to be today's food award" << endl;
    cout << "1 - potatos, \n2 - coconuts, \n3 - meat, \n4 - merenda, \n5 - nutela" << endl;

    int a=0;
    string food;
    cin >> a;

    switch (a)
    {
        case 1 :
            cout << "Yeah! Potatos is a good choice." << endl;
            food = "potatos";
            break;
        case 2 :
            cout << "Hmm.. I think is a bad choice, because coconuts are everywhere in this Island. But ok let's give these to them" << endl;
            food = "coconuts";
            break;
        case 3 :
            cout << "Oh yes! that's perfect, let's see their reaction." << endl;
            food = "meat";
            break;
        case 4 :
            cout << "Merenda.. Ameno Domine!" << endl;
            food = "merenda";
            break;
        case 5 :
            cout << "I knew it! Nutela one love!" << endl;
            food = "nutela";
            break;
        default :
            cout << "I told you to choose one of them..\n So, it's my turn! I'll give them burgers" << endl;
            food = "burgers";
            break;
    }


    TeamCompetition tcd(competitionId=0, "teamCompetition", "Not yet", food, false);
    int winner=tcd.compete(teams[0], teams[1]);

    if (winner ==0)
        cout << "Unfortunately, " << teams[0].getName() << " lost the battle. \nNow we are here to see who will win the Immunity Competition" << endl;
    else
        cout << "Unfortunately, " << teams[1].getName() << " lost the battle. \nNow we are here to see who will win the Immunity Competition" << endl;

    ImmunityAward ia2;
    ImmunityCompetition imc(competitionId=1,"ProtoAgonismaAsylias", "Not yet" , "kolie", true);
    if (winner==0)
        imc.compete(teams[0]);
    else
        imc.compete(teams[1]);

    teams[0].teamEats();
    teams[0].teamSleeps();

    teams[1].teamEats();
    teams[1].teamSleeps();
}

void quizDay()
{

    cout << "This is a quiz day in the Survivor Game." << endl << endl;

    teams[0].teamWorks();
    teams[1].teamWorks();

    CommunicationAward ca3;
    QuizCompetition qc(1, "ProtoAgonismaQuiz", "None yet", "Community", false);
    qc.compete(teams[0], teams[1]);


    teams[0].teamEats();
    teams[0].teamSleeps();

    teams[1].teamEats();
    teams[1].teamSleeps();

}
