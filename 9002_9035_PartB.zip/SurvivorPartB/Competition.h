//  DIKO MAS
#ifndef COMPETITION_H_INCLUDED
#define COMPETITION_H_INCLUDED

#include <iostream>

using namespace std;

class Competition
{
protected:
    int id;
    string name;
    string winner;
public:
    Competition();
    Competition(int id, string name, string winner);
    ~Competition();

    int getId()                     {return id;}
    string getName()                {return name;}
    string getWinner()              {return winner;}

    void setId(int value)           {id=value;}
    void setName(string value)      {name=value;}
    void setWinner(string value)    {winner=value;}

    void status();
};


#endif // COMPETITION_H_INCLUDED
