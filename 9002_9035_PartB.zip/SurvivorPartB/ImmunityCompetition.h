#ifndef IMMUNITYCOMPETITION_H_INCLUDED
#define IMMUNITYCOMPETITION_H_INCLUDED

#include "ImmunityAward.h"
#include "Competition.h"
#include "Team.h"
#include "Player.h"

using namespace std;

class ImmunityCompetition: public Competition
{
    ImmunityAward immunityAward;

public:
    ImmunityCompetition();
    ImmunityCompetition(int id, string name, string winner, string v1, bool v2);
    ~ImmunityCompetition();

    ImmunityAward getImmunityAward() {return immunityAward;}

    void setImmunityAward(string v1, bool v2, int v3);

    void status();
    void compete(Team &value);

};

#endif // IMMUNITYCOMPETITION_H_INCLUDED
